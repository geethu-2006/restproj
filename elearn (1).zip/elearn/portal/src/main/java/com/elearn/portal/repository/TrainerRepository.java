package com.elearn.portal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.elearn.portal.entity.Trainer;



public interface TrainerRepository extends JpaRepository<Trainer, Long> {
//  @Query("SELECT t FROM Trainer t WHERE t.specialization LIKE %:specialization%")
//     List<Trainer> findTrainersBySpecialization(@Param("specialization") String specialization);
}

