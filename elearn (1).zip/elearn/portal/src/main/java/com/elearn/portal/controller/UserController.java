package com.elearn.portal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.elearn.portal.entity.User;
import com.elearn.portal.service.UserService;


@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    // @PostMapping
    // public User createUser(@RequestBody User user) {
    //     return userService.createUser(user);
    // }

    @GetMapping("/{id}")
    public User getUser(@PathVariable Long id) {
        return userService.getUserById(id);
    }
    @GetMapping
    public List<User> getAllUsers()
    {
        return userService.getAllUsers();
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }
    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id,@RequestBody User userdetails)
    {
          return userService.updateUser(id, userdetails);
    }
    //JPQL Methods
    @GetMapping("/search")
    public List<User> getUsersByUsernameOrEmail(@RequestParam(required = false) String username, @RequestParam(required = false) String email) {
        return userService.findUsersByUsernameOrEmail(username, email);
    }
    
    //Pagination
    @GetMapping("/paging")
    public Page<User> getEmployee(@RequestParam (defaultValue="1")int page,@RequestParam (defaultValue="3")int size) {
        return userService.getPageEmployee(page, size);
    }
    
    //Sorting
    @GetMapping("/get/sort/{designation}")
    public List<User> getSorted(@PathVariable String designation)
    {
        return userService.getSorted(designation);
    }
     // Handle POST request to create a new user
    @PostMapping
    public ResponseEntity<String> createUser(@RequestBody User user) {
        // Call the service method
        String responseMessage = userService.createUser(user);
        
        // If the email exists, return a BAD_REQUEST with the message
        if (responseMessage.startsWith("Email already exists")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseMessage);
        }
        
        // If user is created successfully, return CREATED status with the success message
        return ResponseEntity.status(HttpStatus.CREATED).body(responseMessage);
    }
}
