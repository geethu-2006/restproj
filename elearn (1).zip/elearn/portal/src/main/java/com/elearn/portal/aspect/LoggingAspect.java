package com.elearn.portal.aspect;

public class LoggingAspect {
    
}
