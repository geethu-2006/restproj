package com.elearn.portal.exception;

public class ResourceNotFoundException {
    
}
