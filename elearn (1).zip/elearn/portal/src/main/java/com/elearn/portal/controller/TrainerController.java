package com.elearn.portal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.elearn.portal.entity.Trainer;

import com.elearn.portal.service.TrainerService;

@RestController
@RequestMapping("/trainers")
public class TrainerController {

    private static final Trainer Long = null;
        @Autowired
        private TrainerService trainerService;
    
        @PostMapping
        public Trainer createTrainer(@RequestBody Trainer trainer) {
            return trainerService.createTrainer(trainer);
        }
     @GetMapping
    public List<Trainer> getAllUsers()
    {
        return trainerService.getAllTrainers();
    }
        @GetMapping("/{id}")
        public Trainer getTrainer(@PathVariable Long id) {
            return trainerService.getTrainerById(id);
        }
    
        @DeleteMapping("/{id}")
        public void deleteTrainer(@PathVariable Long id) {
            trainerService.createTrainer(Long);
    }
    @PutMapping("/{id}")
    public Trainer updateTrainer(@PathVariable Long id, @RequestBody Trainer updatedTrainer) {
        // Check if the trainer exists
        Trainer existingTrainer = trainerService.getTrainerById(id);
        if (existingTrainer == null) {
            // Handle trainer not found scenario (404 response)
            return null; // or throw a custom exception with a meaningful message
        }

        // Update the existing trainer with new data
        existingTrainer.setName(updatedTrainer.getName());
        existingTrainer.setEmail(updatedTrainer.getEmail());
        existingTrainer.setSpecialization(updatedTrainer.getSpecialization());

        // Save the updated trainer and return it
        return trainerService.createTrainer(existingTrainer); // You can reuse createTrainer method for saving
    }
}
