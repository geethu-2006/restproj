package com.elearn.portal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.elearn.portal.entity.User;
import com.elearn.portal.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // public User createUser(User user) {
    //     return userRepository.save(user);
    // }

    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
    public User updateUser(User user) {
        return userRepository.save(user);
    }

    public List<User> getAllUsers() {
       return userRepository.findAll();
    }
    //JPQL Methods
public List<User> findUsersByUsernameOrEmail(String username,String email)
{
    return userRepository.findUsersByUsernameOrEmail(username,email);
}
 
//Pagination
    public Page<User> getPageEmployee(@RequestParam int page,@RequestParam int size){
        PageRequest pageable=PageRequest.of(page,size);
        return userRepository.findAll(pageable);
    }
    //Sorting
    public List<User> getSorted(String designation)
    {
        return userRepository.findAll(Sort.by(Sort.Direction.ASC,designation));
    }
   
    public String createUser(User user) {
        // Check if email already exists
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            // If email exists, return a simple message
            return "Email already exists: " + user.getEmail();
        }
        
        // If email doesn't exist, save the new user
        userRepository.save(user);
        return "User created successfully"; // Return success message
    }
    public User updateUser(Long id, User userdetails) {
        userdetails.setId(id);
        return userRepository.save(userdetails);
    }
}


    

