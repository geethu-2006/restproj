package com.elearn.portal.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.elearn.portal.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
// @Query("SELECT u FROM User u WHERE u.email LIKE %@:domain")
//     List<User> findUsersByEmailDomain(@Param("domain") String domain);
    @Query("SELECT u FROM User u WHERE u.username = :username OR u.email = :email")
    List<User> findUsersByUsernameOrEmail(@Param("username") String username, @Param("email") String email);
    
    Optional<User> findByEmail(String email); // Method to check if the email exists
    //Page<User> findAll(Pageable pageable);
}








